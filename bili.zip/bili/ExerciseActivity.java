package com.example.bili;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ExerciseActivity extends AppCompatActivity {

    private Button mBtnLinear,mBtnHor,mBtnPuBu,mBtnWebView,mBtnDialog,mBtnProgress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise);

        mBtnLinear = findViewById(R.id.btn_linear);
        mBtnHor = findViewById(R.id.btn_hor);
        mBtnPuBu = findViewById(R.id.btn_pubu);
        mBtnWebView = findViewById(R.id.btn_webView);
        mBtnDialog = findViewById(R.id.btn_dialog);
        mBtnProgress = findViewById(R.id.btn_progress);
        setListeners();
    }

    private void setListeners() {
        OnClick onClick = new OnClick();
        mBtnLinear.setOnClickListener(onClick);
        mBtnHor.setOnClickListener(onClick);
        mBtnPuBu.setOnClickListener(onClick);
        mBtnWebView.setOnClickListener(onClick);
        mBtnDialog.setOnClickListener(onClick);
        mBtnProgress.setOnClickListener(onClick);
    }

    private class OnClick implements View.OnClickListener{
        public void onClick(View v){
            Intent intent = null;
            switch (v.getId()){
                case R.id.btn_linear:
                    intent = new Intent(ExerciseActivity.this,LinearRecyclerViewActivity.class);
                    break;
                case R.id.btn_hor:
                    intent = new Intent(ExerciseActivity.this,HorRecyclerViewActivity.class);
                    break;
                case R.id.btn_pubu:
                    intent = new Intent(ExerciseActivity.this,PuBuRecyclerViewActivity.class);
                    break;
                case R.id.btn_webView:
                    intent = new Intent(ExerciseActivity.this,WebViewActivity.class);
                    break;
                case R.id.btn_dialog:
                    intent = new Intent(ExerciseActivity.this,DialogActivity.class);
                    break;
                case R.id.btn_progress:
                    intent = new Intent(ExerciseActivity.this,ProgressActivity.class);
                    break;
            }
            startActivity(intent);
        }
    }
}