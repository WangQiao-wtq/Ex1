package com.example.bili;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebViewActivity extends AppCompatActivity {

    private WebView mMvMain;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);

        mMvMain = findViewById(R.id.wv);
        //加载本地HTML
//        mMvMain.loadUrl("file:///android_asset/test.html");
        //加载网络HTML
        mMvMain.getSettings().setJavaScriptEnabled(true);//设置JS能支持
        mMvMain.setWebViewClient(new MyWebView());
        mMvMain.setWebChromeClient(new MyWebViewChromeClient());
        mMvMain.loadUrl("https://m.baidu.com");
    }

    class MyWebView extends WebViewClient{
        @RequiresApi(api = Build.VERSION_CODES.N)
        public boolean shouldOverrrideUrlLoading(WebView view, WebResourceRequest request){
            view.loadUrl(request.getUrl().toString());
            return super.shouldOverrideUrlLoading(view,request);
        }
        public void onPageStarted(WebView view, String url, Bitmap favicon){
            super.onPageStarted(view,url,favicon);
            Log.d("webview","onPageStarted...");
        }
        public void onPageFinished(WebView view, String url, Bitmap favicon){
            super.onPageStarted(view,url,favicon);
            Log.d("webview","onPageFInished...");
        }
    }

    class MyWebViewChromeClient extends WebChromeClient{
        public void onProgressChanged(WebView view,int newProgress){
            super.onProgressChanged(view,newProgress);
        }
        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
            setTitle(title);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK && mMvMain.canGoBack()){
            mMvMain.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}