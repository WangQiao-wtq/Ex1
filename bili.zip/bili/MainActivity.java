package com.example.bili;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import com.example.bili.util.ToastUtil;

public class MainActivity extends AppCompatActivity {

    //声明控件
    private Button mBtnLogin,mBtnRegister,mBtn;
    private EditText mEtUsr;
    private EditText mEtPassword;
    private ImageView mIv;
    private TextView mTv;
    private double s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //找到控件
        mBtnLogin = findViewById(R.id.btn_login);
        mEtUsr = findViewById(R.id.et_1);
        mEtPassword = findViewById(R.id.et_2);
        mIv = findViewById(R.id.iv_1);
        mBtnRegister = findViewById(R.id.btn_register);
        mBtn = findViewById(R.id.btn);
        mTv = findViewById(R.id.tv);

//        //实现直接跳转——方法一:
//        mBtnLogin.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = null;
//                intent = new Intent(MainActivity.this,FuncLoginActivity.class);
//                startActivity(intent);
//            }
//        });

        //匹配对应的用户名和密码才能进行登录操作
        mBtnLogin.setOnClickListener(this::onClick);
        mBtnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,RegisterActivity.class);
                startActivity(intent);
            }
        });

        mBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initPython();
                s=callPythonCode();
                int y=(int) s;
                mTv.setText(" "+y);
            }
        });

    }
    public void onClick(View v)
    {
        //需要获取输入的用户名和密码
        String username = mEtUsr.getText().toString();
        String password = mEtPassword.getText().toString();

        //弹出的内容设置
        String ok = "登录成功！";
        String fail = "账号或密码有误，请重新登录！";
        Intent intent = null;

        //假设正确的账号和密码分别是wq,123456
        if(username.equals("wq") && password.equals("123")){
            //toast普通版
            //Toast.makeText(getApplicationContext(),ok,Toast.LENGTH_SHORT).show();

            //封装好的类，不用写一长串的
            ToastUtil.showMsg(MainActivity.this,ok);
            //如果正确则进行跳转,from MainActivity to SlideActivity
            intent = new Intent(MainActivity.this, SlideActivity.class);
            startActivity(intent);
        }else{
            //不正确，弹出登录失败toast
            //提升版，居中显示
//            Toast toastCenter = Toast.makeText(getApplicationContext(),fail,Toast.LENGTH_SHORT);
//            toastCenter.setGravity(Gravity.CENTER,0,0);
//            toastCenter.show();
            ToastUtil.showMsg(MainActivity.this,fail);
        }

    }

    void initPython(){
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(MainActivity.this));
        }
    }
    double callPythonCode() {
        Python py = Python.getInstance();
        PyObject pyObject = py.getModule("Similarity").callAttr("calculate");
        s=pyObject.toDouble();
        return s;
    }
}