package com.example.bili.Adapter;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.bili.R;


public class ListViewAdapter extends BaseAdapter{
    private Context mContext;
    private LayoutInflater mLayoutInflater;

    public ListViewAdapter(Context context){
        this.mContext = context;
        mLayoutInflater = LayoutInflater.from(context);
    }
    @Override
    public int getCount() {
        return 10;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    public class ViewHolder{
        public ImageView imageview;
        public TextView textTitle,textTime,textContent;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder = null;
        if(view == null){
            view = mLayoutInflater.inflate(R.layout.course_item,null);
            holder = new ViewHolder();
            holder.imageview  = view.findViewById(R.id.iv);
            holder.textTitle = view.findViewById(R.id.finish_title);
            holder.textTime = view.findViewById(R.id.finish_time);
            holder.textContent = view.findViewById(R.id.finish_content);
            view.setTag(holder);
        }else{
            holder = (ViewHolder) view.getTag();
        }
        holder.textTitle.setText("追星方法");
        holder.textTime.setText("2021-10-01");
        holder.textContent.setText("you can't miss it！");
        Glide.with(mContext).load("https://img2.baidu.com/it/u=1617264298,2995204210&fm=26&fmt=auto").into(holder.imageview);
        return view;
    }
}
