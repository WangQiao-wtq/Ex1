package com.example.bili.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bili.R;

import java.util.List;

public class StaggeredAdapter extends RecyclerView.Adapter<StaggeredAdapter.LinearViewHolder> {
    private Context mContext;
    private OnItemClickListener mListener;
//    private OnItemLongClickListener mLongListener;
    private List<String> list;

    public StaggeredAdapter(Context context, OnItemClickListener listener) {
        this.mContext = context;
        this.mListener = listener;
//        this.mLongListener = longListener;
    }
    public StaggeredAdapter.LinearViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new LinearViewHolder(LayoutInflater.from(mContext).inflate(R.layout.layout_staggered_item,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull StaggeredAdapter.LinearViewHolder holder, int position) {
        if(position%2 != 0){
            holder.imageView.setImageResource(R.drawable.bg1);
        }else{
            holder.imageView.setImageResource(R.drawable.bg2);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.onClick(position);
            }
        });
//        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View view) {
//                mLongListener.onClick(position);
//                return true;
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return 30;
    }
    class LinearViewHolder extends RecyclerView.ViewHolder{ //定义了一个类
        private ImageView imageView;
        public LinearViewHolder(View itemView){ //构造方法
            super(itemView);
            imageView = itemView.findViewById(R.id.iv);
        }
    }
    public interface OnItemClickListener{ //定义一个接口
        void onClick(int pos);
    }
//    public interface OnItemLongClickListener{
//        void onClick(int pos);
//    }
}
