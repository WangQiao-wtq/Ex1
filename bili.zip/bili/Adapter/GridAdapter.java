package com.example.bili.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bili.R;

import java.util.List;

public class GridAdapter extends RecyclerView.Adapter<GridAdapter.LinearViewHolder> {
    private Context mContext;
    private OnItemClickListener mListener;
//    private OnItemLongClickListener mLongListener;
    private List<String> list;

    public GridAdapter(Context context, OnItemClickListener listener) {
        this.mContext = context;
        this.mListener = listener;
//        this.mLongListener = longListener;
    }
    public GridAdapter.LinearViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new LinearViewHolder(LayoutInflater.from(mContext).inflate(R.layout.layout_grid_recyclerview_item,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull GridAdapter.LinearViewHolder holder, int position) {
        holder.textView.setText("hello!");//设置每个item的textview的内容
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.onClick(position);
            }
        });
//        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View view) {
//                mLongListener.onClick(position);
//                return true;
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return 90;
    }
    class LinearViewHolder extends RecyclerView.ViewHolder{ //定义了一个类
        private TextView textView;
        public LinearViewHolder(View itemView){ //构造方法
            super(itemView);
            textView = itemView.findViewById(R.id.tv_title);
        }
    }
    public interface OnItemClickListener{ //定义一个接口
        void onClick(int pos);
    }
//    public interface OnItemLongClickListener{
//        void onClick(int pos);
//    }
}
