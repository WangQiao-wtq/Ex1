package com.example.bili;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.bili.Adapter.ListViewAdapter;

public class PlayActivity extends AppCompatActivity {

    private ListView mRVFinish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        mRVFinish = findViewById(R.id.rv_1);


        mRVFinish.setAdapter(new ListViewAdapter(PlayActivity.this));
        mRVFinish.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(PlayActivity.this,"点击 pos"+i,Toast.LENGTH_SHORT).show();
            }
        });
        mRVFinish.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(PlayActivity.this,"长按 pos"+i,Toast.LENGTH_SHORT).show();
                return true;//如果return false 则在长按事件处理完后，又会处理点击事件
                //return false 意思是告诉点击方法我已经处理完长按事件了，让他不要再处理了
            }
        });
    }
}