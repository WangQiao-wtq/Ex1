package com.example.bili;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;
import android.widget.ListView;

import com.bumptech.glide.load.resource.gif.GifBitmapProvider;
import com.example.bili.Adapter.MyGridViewAdapter;

public class RegisterActivity extends AppCompatActivity {

    private GridView mGv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mGv = findViewById(R.id.gv);
        mGv.setAdapter(new MyGridViewAdapter(RegisterActivity.this));


    }
}