package com.example.bili;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.graphics.Rect;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.bili.Adapter.StaggeredAdapter;

public class PuBuRecyclerViewActivity extends AppCompatActivity {

    private RecyclerView mRvPu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pu_bu_recycler_view);

        mRvPu = findViewById(R.id.rv_pu);
        mRvPu.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));
        //是vertical垂直的 则前面的2表示有多少列
        mRvPu.addItemDecoration(new MyDecoration());
        mRvPu.setAdapter(new StaggeredAdapter(PuBuRecyclerViewActivity.this, new StaggeredAdapter.OnItemClickListener() {
            @Override
            public void onClick(int pos) {
                Toast.makeText(PuBuRecyclerViewActivity.this, "click..." + pos, Toast.LENGTH_SHORT).show();
            }
        }));
    }
    class MyDecoration extends RecyclerView.ItemDecoration{
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent,RecyclerView.State state){
            super.getItemOffsets(outRect,view,parent,state);
            int gap = getResources().getDimensionPixelOffset(R.dimen.dividerHeight);
            outRect.set(gap,gap,gap,gap);
        }
    }
}