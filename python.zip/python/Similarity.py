import json
import os
import numpy
#import operator
from math import fabs, sqrt
from scipy.stats import pearsonr
from os.path import dirname,join

import scipy.spatial.distance

dirpath = join(dirname(__file__),'json')
dirpaths = join(dirname(__file__),'jsons')
files = os.listdir(dirpath)
files1 = os.listdir(dirpaths)
s = 0
m = 0

def calculate(): #函数

    sum = 0
    sscore = 0
    fenshu = []
    zongfen = 0
    for i in range(len(files)):
            with open(os.path.join(dirpath,files[i]),'r',encoding = 'utf8') as fp:
                json_data = json.load(fp)
            with open(os.path.join(dirpaths,files1[i]),'r',encoding = 'utf8') as fp1:
                jjson_data = json.load(fp1)

                for x in range(len(json_data)):
                    # print(json_data)
                    # print(jjson_data)
                    for k in range(34):
                        #if(operator.eq(json_data[x][k:k + 2:],[0.0,0.0]) == 1 | operator.eq(jjson_data[x][k:k + 2:],[0.0,0.0]) == 1):
                        if ((json_data[x][k] < 1e-6) & (json_data[x][k + 1] < 1e-6)) | ((jjson_data[x][k] < 1e-6) & (jjson_data[x][k + 1] < 1e-6)):
                            s = 0
                        else:
                            #s = cosine(json_data[x][k:k + 2:], jjson_data[x][k:k + 2:])

                            s = fabs((json_data[x][k]*jjson_data[x][k] + json_data[x][k+1]*jjson_data[x][k+1]) \
                                     / (sqrt(pow(json_data[x][k],2)+pow(json_data[x][k+1],2)) * sqrt(pow(jjson_data[x][k],2)+pow(jjson_data[x][k+1],2))))
                        sum += s  #sum表示每一帧里面每一个人和教学视频里面对应的人的余弦相似度
                        # print(s)
                    # print("______________________")
                    score = sum / 34 * 100 #score表示每一帧里面每一个人和教学视频里面对应的人的分数
                    # print(score)
                    sscore += score #sscore表示练习视频一帧里面所有人的分数总和
                    # print("______________________")
                    sum = 0
                # print("总分为： ")
                # print(sscore / len(json_data)) #算出来的是练习视频一帧的分数用所有人的平均分所替代 即下面的列表fenshu[]的每一个值
                fenshu.append(sscore / len(json_data))
                # print("-------------------------------------------------")
                sscore = 0

    for i in range(len(fenshu)):
        # print("-----------------------------------------")
        # print(fenshu[i])
        zongfen += fenshu[i] #所有帧的分数的总和

    # print("-----------------------------------------")
    # print("相似度为：")
    # print("此结果为百分比形式：")
    # print(zongfen / len(files))
    # print("-----------------------------------------")
    return zongfen / len(files)


    # 整齐度
    # sum1 = 0.00
    # sum2 = 0.00
    # sum3 = 0.00
    # i = 0
    # z = 0
    # result = 0.00
    # sum4=0.00

    # while i < len(files):
    #     with open(os.path.join(dirpath, files[i]), 'r', encoding='utf8') as fp:
    #         t = json.load(fp)
    #         j = len(t)
    #         while j > 1:
    #             list = t[0]
    #             list1 = t[len(t) - j + 1]
    #
    #             while z < len(list):
    #                 sum1 = sum1 + list[z] * list[z]
    #                 sum2 = sum2 + list1[z] * list1[z]
    #                 sum3 = sum3 + list[z] * list1[z]
    #                 z = z + 1
    #             sum1 = sum1 ** 0.5
    #             sum2 = sum2 ** 0.5
    #             if (sum1 * sum2) == 0:
    #                 result = result + 0
    #             else:
    #                 result = result + sum3 / (sum1 * sum2)
    #                 print(result)
    #             j = j - 1
    #
    #         if len(t) > 0:
    #             result = result / (len(t) - 1)
    #             sum4 = sum4 + result
    #             result = 0.00
    #         i = i + 1
    #
    # print("舞蹈整齐度为：")
    # print((sum4 / i) * 100)

    # print("--------------------------")
    # print("用户此段练习视频评分为：")
    # print((sum4 / i) * 100 * 0.3 + (zongfen/len(files) * 0.7))